import Login from './components/Login/Login';
import Navbar from './components/Navbar/Navbar';

import './scss/app.css'

function App() {

  return (
    <div>
        <Navbar/>
        <Login/>
    </div>
     
  );
}

export default App;
