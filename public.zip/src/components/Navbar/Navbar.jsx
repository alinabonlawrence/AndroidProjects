import React from 'react'

export default function Navbar() {
    return (
        <nav>
            <div className="navbar">
                <div className="navbar__brand">
                    <h5>TILDE</h5>
                </div>
                <div className="navbar__button">
                    <h5>|||</h5>
                </div>
            </div> 
        </nav>
    )
}
