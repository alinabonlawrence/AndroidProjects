import React from 'react'

export default function Login() {
    return (
        <div className="login">
            <div className="row">
                <div className="c-col-sm-12">
                </div>
                <div className="login_container c-col-sm-12">
                    <div className="card">
                        <div class="login__form">
                            <p>Email Address </p>
                            <input></input>
                            <p>Password </p>
                            <input></input>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}
